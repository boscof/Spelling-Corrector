Following the instructions set in the assignment guidelines, this zip file should be used as follows:

Program - this implementation is done in Java. The main programs are located in the src folder where 'Spellings.java' contains the main program for single prediction models and 'MultipleSpellings.java' contains the main program for multi prediction models. The programs are to be compiled normally using javac.

Output - the output is stored in the text file located in the output folder. The output distinguishes between single prediction models and multi prediction models. For example, the output from the single prediction bigram method is stored in '[your directory]\output\single\biGram-output'.

Report - the latex files are located in the report folder.

