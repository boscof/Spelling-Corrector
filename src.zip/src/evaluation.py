# -*- coding:utf-8 -*-
import pandas as pd
import os


class evaluation:
    def __init__(self):
        self.evaluation_table = pd.DataFrame(columns=['misspell_word', 'correct_word', 'predicted_word', 'matchOrNot'])
        self.precision_table = pd.DataFrame(
            columns=['misspell_word', 'correct_word', 'predicted_word_list',
                     'length_of_predicted_word_list', 'if_any_match'])
        self.outdir = os.pardir + '/results/'

    def accuracy(self, misspell_word_list, correct_word_list, predicted_word_list, method):
        self.evaluation_table['misspell_word'] = misspell_word_list
        self.evaluation_table['correct_word'] = correct_word_list
        self.evaluation_table['predicted_word'] = predicted_word_list

        for row in range(len(misspell_word_list)):
            if self.evaluation_table['predicted_word'][row] == self.evaluation_table['correct_word'][row]:
                self.evaluation_table['matchOrNot'][row] = 1
            else:
                self.evaluation_table['matchOrNot'][row] = 0

        self.evaluation_table.to_csv(self.outdir + "accuracy_table_" + method + '.csv', index=False)
        return self.evaluation_table

    def precision(self, misspell_word_list, correct_word_list, precision_list, method):
        self.precision_table['misspell_word'] = misspell_word_list
        self.precision_table['correct_word'] = correct_word_list
        self.precision_table['predicted_word_list'] = precision_list
        for i in range(len(misspell_word_list)):
            self.precision_table['length_of_predicted_word_list'][i] = len(
                self.precision_table['predicted_word_list'][i])
            if self.precision_table['correct_word'][i] in self.precision_table['predicted_word_list'][i]:
                self.precision_table['if_any_match'][i] = 1
            else:
                self.precision_table['if_any_match'][i] = 0

        self.precision_table.to_csv(self.outdir + "precision_table_" + method + '.csv', index=False)
        return self.precision_table
