# -*- coding:utf-8 -*-
import time
import random as rd
import os
import swalign
import ngram
import jellyfish
import editdistance
from collections import Counter

from Assignment_1.src.evaluation import evaluation
from Assignment_1.src.algorithms import KT_Algorithms


def load_data():
    """
    load data from txt files
    :return: correct, dictionary, and misspell words in dictionaries with initial value of 0.
    """
    correct_list = []

    file_path = os.pardir
    with open(file_path + '/' + '2018S1-90049P1-data/' + 'correct.txt', 'r') as f:
        lines = f.readlines()
        for line in lines:
            correct_list.append(line.strip())  # string.strip() get rid of \n at the end of each line

    correct_dict = dict.fromkeys(correct_list, 0)  # create a default dict with words as keys and zero as values

    dictionary_list = []
    with open(file_path + '/' + '2018S1-90049P1-data/' + 'dictionary.txt', 'r') as f:
        lines = f.readlines()
        for line in lines:
            dictionary_list.append(line.strip())  # string.strip() get rid of \n at the end of each line

    dictionary_dict = dict.fromkeys(dictionary_list, 0)  # create a default dict with words as keys and zero as values

    misspell_list = []
    with open(file_path + '/' + '2018S1-90049P1-data/' + 'misspell.txt', 'r') as f:
        lines = f.readlines()
        for line in lines:
            misspell_list.append(line.strip())  # string.strip() get rid of \n at the end of each line

    misspell_dict = dict.fromkeys(misspell_list, 0)  # create a default dict with words as keys and zero as values

    return correct_list, correct_dict, dictionary_list, dictionary_dict, misspell_list, misspell_dict


def cut_down_search_space(word, lst, keep_first_alphabet=False, left_right_window=2):
    """
    Use similar idea of neighbourhood search
    The idea here is to cut down search space by filtering out the "obvious-not-the-solution" words.
    When we have typos, we are most likely to type an incorrect word that has same or similar length with
    the correct answer.
    e.g. accually has a length of 8, actually has a length of 8
    e.g egat has a length of 4, egads has a length of 5
    So we can cut down our search space into a dictionary with all similar words
    Additionally, we may even cut down the search space by assuming that people are less likely to got the first
    alphabet wrong.
    May not necessarily improve accuracy but significantly improve the speed.
    :param lst: input lst
    :return: a new lst and dictionary that has limited search space
    """

    lw = len(word)
    new_lst = []
    for i in range(len(lst)):
        if keep_first_alphabet is True:
            if lst[i][0] == word[0]:
                if (len(lst[i]) <= (lw + left_right_window)) and (len(lst[i]) >= (lw - left_right_window)):
                    new_lst.append(lst[i])
        elif keep_first_alphabet is False:
            if (len(lst[i]) <= (lw + left_right_window)) and (len(lst[i]) >= (lw - left_right_window)):
                new_lst.append(lst[i])

    new_dict = dict.fromkeys(new_lst, 0)
    return new_lst, new_dict


def choose_max_or_min(dic, reverse=True):
    """
    :param dic:
    :param reverse: True if find max
    :return: a list of keys with maximum values
    """
    li = list(dic.items())
    li.sort(key=lambda k: k[1], reverse=reverse)
    dic = dict(li)
    values = list(dic.values())
    keys = list(dic.keys())
    index = 0
    ld = len(dic)
    while index < ld:
        if values[index] is values[0]:
            index += 1
        else:
            break
    return list(keys[0:index])

    # return [x[0] for x in li[:3]]


def most_common(lst):
    data = Counter(lst)
    return max(lst, key=data.get)


def random_sample(lst1, lst2, size=10):
    """
    Return a random list of size = size, and initialize dictionary
    :param lst: input list
    :param size:
    :return:
    """
    assert len(lst1) == len(lst2)
    empty_list_1 = []
    empty_list_2 = []
    rd.seed(1000)  # fix seed
    for i in range(size):
        index = rd.randint(0, len(lst1))
        empty_list_1.append(lst1[index])
        empty_list_2.append(lst2[index])

    dic1 = dict.fromkeys(lst1[0:size], 0)
    dic2 = dict.fromkeys(lst2[0:size], 0)

    return lst1[0:size], dic1, lst2[0:size], dic2


def Levenshtein_Global_Edit_Distance(much_faster=True):
    if much_faster is True:
        method = 'LevenshteinGlobalEditDistance_much_faster'
    else:
        method = 'LevenshteinGlobalEditDistance'
    correct_list, correct_dict, dictionary_list, dictionary_dict, misspell_list, misspell_dict = load_data()  # Load data

    evaluations = evaluation()  # create an evaluation instance
    predicted_word_list = []  # initialize an empty list to record the predicted word list
    precision_list = []  # initialize an empty list to record information required for precision evaluation

    start = time.clock()
    for each_misspell_word in misspell_list:

        if much_faster is True:
            new_dictionary_list, new_dictionary_dict = cut_down_search_space(each_misspell_word, dictionary_list,
                                                                             keep_first_alphabet=False,
                                                                             left_right_window=2)
        else:
            new_dictionary_list, new_dictionary_dict = dictionary_list, dictionary_dict

        for each_dictionary_word in new_dictionary_list:
            # dictionary_dict[each_dictionary_word] = editdistance.eval(each_misspell_word, each_dictionary_word)
            new_dictionary_dict[each_dictionary_word] = jellyfish.levenshtein_distance(each_misspell_word,
                                                                                       each_dictionary_word)
        find_word = min(new_dictionary_list, key=new_dictionary_dict.get)
        precision_list.append(choose_max_or_min(new_dictionary_dict, reverse=False))
        predicted_word_list.append(find_word)
        print('{} done, find the word: {}'.format(each_misspell_word, find_word))
    end = time.clock()

    evaluations.accuracy(correct_word_list=correct_list, misspell_word_list=misspell_list,
                         predicted_word_list=predicted_word_list, method=method)  # evaluate accuracy
    evaluations.precision(correct_word_list=correct_list, misspell_word_list=misspell_list,
                          precision_list=precision_list, method=method)  # evaluate precision

    print('{} method done, time: {}'.format(method, (end - start)))


def damerau_Levenshtein_Distance_Global_Edit_Distance(much_faster=True):
    if much_faster is True:
        method = 'damerauLevenshtein_much_faster'
    else:
        method = 'damerauLevenshtein'
    correct_list, correct_dict, dictionary_list, dictionary_dict, misspell_list, misspell_dict = load_data()  # Load data

    evaluations = evaluation()  # create an evaluation instance
    predicted_word_list = []  # initialize an empty list to record the predicted word list
    precision_list = []  # initialize an empty list to record information required for precision evaluation

    start = time.clock()

    for each_misspell_word in misspell_list:
        if much_faster is True:
            new_dictionary_list, new_dictionary_dict = cut_down_search_space(each_misspell_word, dictionary_list,
                                                                             keep_first_alphabet=False,
                                                                             left_right_window=2)
        else:
            new_dictionary_list, new_dictionary_dict = dictionary_list, dictionary_dict

        for each_dictionary_word in new_dictionary_list:
            new_dictionary_dict[each_dictionary_word] = jellyfish.damerau_levenshtein_distance(each_misspell_word,
                                                                                               each_dictionary_word)
        find_word = min(new_dictionary_list, key=new_dictionary_dict.get)
        precision_list.append(choose_max_or_min(new_dictionary_dict, reverse=False))
        predicted_word_list.append(find_word)
        print('{} done, find the word: {}'.format(each_misspell_word, find_word))
    end = time.clock()

    evaluations.accuracy(correct_word_list=correct_list, misspell_word_list=misspell_list,
                         predicted_word_list=predicted_word_list, method=method)  # evaluate accuracy
    evaluations.precision(correct_word_list=correct_list, misspell_word_list=misspell_list,
                          precision_list=precision_list, method=method)  # evaluate precision

    print('{} method done, time: {}'.format(method, (end - start)))


def local_Distance(much_faster=True):
    algos = KT_Algorithms()
    if much_faster is True:
        method = 'Smith_Waterman_much_faster'
    else:
        method = 'Smith_Waterman'
    correct_list, correct_dict, dictionary_list, dictionary_dict, misspell_list, misspell_dict = load_data()  # Load data

    evaluations = evaluation()  # create an evaluation instance
    predicted_word_list = []  # initialize an empty list to record the predicted word list
    precision_list = []  # initialize an empty list to record information required for precision evaluation

    start = time.clock()
    for each_misspell_word in misspell_list:

        if much_faster is True:
            new_dictionary_list, new_dictionary_dict = cut_down_search_space(each_misspell_word, dictionary_list,
                                                                             keep_first_alphabet=False,
                                                                             left_right_window=2)
        else:
            new_dictionary_list, new_dictionary_dict = dictionary_list, dictionary_dict

        for each_dictionary_word in new_dictionary_list:
            new_dictionary_dict[each_dictionary_word] = algos.Smith_Waterman(each_misspell_word, each_dictionary_word)
        find_word = max(new_dictionary_dict, key=new_dictionary_dict.get)
        precision_list.append(choose_max_or_min(new_dictionary_dict, reverse=False))
        predicted_word_list.append(find_word)
        print('{} done, find the word: {}'.format(each_misspell_word, find_word))
    end = time.clock()

    evaluations.accuracy(correct_word_list=correct_list, misspell_word_list=misspell_list,
                         predicted_word_list=predicted_word_list, method=method)  # evaluate accuracy
    evaluations.precision(correct_word_list=correct_list, misspell_word_list=misspell_list,
                          precision_list=precision_list, method=method)  # evaluate precision

    print('{} method done, time: {}'.format(method, (end - start)))


def local_Distance_pkg(much_faster=True):
    if much_faster is True:
        method = 'Smith_Waterman_swaling_pkg_much_faster'
    else:
        method = 'Smith_Waterman_swaling_pkg'
    correct_list, correct_dict, dictionary_list, dictionary_dict, misspell_list, misspell_dict = load_data()  # Load data

    match = 1
    mismatch = -1
    scoring = swalign.NucleotideScoringMatrix(match, mismatch)
    sw = swalign.LocalAlignment(scoring)

    evaluations = evaluation()  # create an evaluation instance
    predicted_word_list = []  # initialize an empty list to record the predicted word list
    precision_list = []  # initialize an empty list to record information required for precision evaluation

    start = time.clock()
    for each_misspell_word in misspell_list:

        if much_faster is True:
            new_dictionary_list, new_dictionary_dict = cut_down_search_space(each_misspell_word, dictionary_list,
                                                                             keep_first_alphabet=False,
                                                                             left_right_window=2)
        else:
            new_dictionary_list, new_dictionary_dict = dictionary_list, dictionary_dict

        for each_dictionary_word in new_dictionary_list:
            new_dictionary_dict[each_dictionary_word] = sw.align(each_misspell_word, each_dictionary_word).score
        find_word = max(new_dictionary_dict, key=new_dictionary_dict.get)
        precision_list.append(choose_max_or_min(new_dictionary_dict, reverse=False))
        predicted_word_list.append(find_word)
        print('{} done, find the word: {}'.format(each_misspell_word, find_word))
    end = time.clock()

    evaluations.accuracy(correct_word_list=correct_list, misspell_word_list=misspell_list,
                         predicted_word_list=predicted_word_list, method=method)  # evaluate accuracy
    evaluations.precision(correct_word_list=correct_list, misspell_word_list=misspell_list,
                          precision_list=precision_list, method=method)  # evaluate precision

    print('{} method done, time: {}'.format(method, (end - start)))


def N_gram(n=2, much_faster=True):
    algos = KT_Algorithms()
    if much_faster is True:
        method = 'N_gram_much_faster'
    else:
        method = 'N_gram'
    correct_list, correct_dict, dictionary_list, dictionary_dict, misspell_list, misspell_dict = load_data()  # Load data

    evaluations = evaluation()  # create an evaluation instance
    predicted_word_list = []  # initialize an empty list to record the predicted word list
    precision_list = []  # initialize an empty list to record information required for precision evaluation

    start = time.clock()
    for each_misspell_word in misspell_list:
        if much_faster is True:
            new_dictionary_list, new_dictionary_dict = cut_down_search_space(each_misspell_word, dictionary_list,
                                                                             keep_first_alphabet=False,
                                                                             left_right_window=2)
        else:
            new_dictionary_list, new_dictionary_dict = dictionary_list, dictionary_dict

        for each_dictionary_word in new_dictionary_list:
            new_dictionary_dict[each_dictionary_word] = algos.N_gram(each_misspell_word, each_dictionary_word, n)
        find_word = min(new_dictionary_dict, key=new_dictionary_dict.get)
        precision_list.append(choose_max_or_min(new_dictionary_dict, reverse=False))
        predicted_word_list.append(find_word)
        print('{} done, find the word: {}'.format(each_misspell_word, find_word))
    end = time.clock()

    evaluations.accuracy(correct_word_list=correct_list, misspell_word_list=misspell_list,
                         predicted_word_list=predicted_word_list, method=method)  # evaluate accuracy
    evaluations.precision(correct_word_list=correct_list, misspell_word_list=misspell_list,
                          precision_list=precision_list, method=method)  # evaluate precision

    print('{} method done, time: {}'.format(method, (end - start)))


def N_gram_pkg(n=2, much_faster=True):
    if much_faster is True:
        method = 'N_gram_PKG_much_faster'
    else:
        method = 'N_gram_PKG'

    correct_list, correct_dict, dictionary_list, dictionary_dict, misspell_list, misspell_dict = load_data()  # Load data

    evaluations = evaluation()  # create an evaluation instance
    predicted_word_list = []  # initialize an empty list to record the predicted word list
    precision_list = []  # initialize an empty list to record information required for precision evaluation

    start = time.clock()
    for each_misspell_word in misspell_list:
        if much_faster is True:
            new_dictionary_list, new_dictionary_dict = cut_down_search_space(each_misspell_word, dictionary_list,
                                                                             keep_first_alphabet=False,
                                                                             left_right_window=2)
        else:
            new_dictionary_list, new_dictionary_dict = dictionary_list, dictionary_dict

        for each_dictionary_word in new_dictionary_list:
            new_dictionary_dict[each_dictionary_word] = ngram.NGram.compare(each_misspell_word, each_dictionary_word,
                                                                            N=n)
        find_word = max(new_dictionary_dict, key=new_dictionary_dict.get)
        precision_list.append(choose_max_or_min(new_dictionary_dict, reverse=True))
        predicted_word_list.append(find_word)
        print('{} done, find the word: {}'.format(each_misspell_word, find_word))
    end = time.clock()

    evaluations.accuracy(correct_word_list=correct_list, misspell_word_list=misspell_list,
                         predicted_word_list=predicted_word_list, method=method)  # evaluate accuracy
    evaluations.precision(correct_word_list=correct_list, misspell_word_list=misspell_list,
                          precision_list=precision_list, method=method)  # evaluate precision

    print('{} method done, time: {}'.format(method, (end - start)))


def Soundex():
    method = 'soundex'
    correct_list, correct_dict, dictionary_list, dictionary_dict, misspell_list, misspell_dict = load_data()  # Load data

    for each_misspell_word in misspell_list:
        misspell_dict[each_misspell_word] = jellyfish.soundex(each_misspell_word)

    for each_dictionary_word in dictionary_list:
        dictionary_dict[each_dictionary_word] = jellyfish.soundex(each_dictionary_word)

    start = time.clock()
    for each_misspell_word in misspell_list:
        lst = []
        for each_dictionary_word in dictionary_list:
            if misspell_dict[each_misspell_word] == dictionary_dict[each_dictionary_word]:
                lst.append(each_dictionary_word)
    end = time.clock()
    print('{} method done, time: {}'.format(method, (end - start)))


def majority_vote(much_faster=True, random_sample_method=True):
    if much_faster is True:
        method = 'majority_vote_much_faster'
    else:
        method = 'majority_vote'
    correct_list, correct_dict, dictionary_list, dictionary_dict, misspell_list, misspell_dict = load_data()  # Load data

    evaluations = evaluation()  # create an evaluation instance
    predicted_word_list = []  # initialize an empty list to record the predicted word list
    precision_list = []  # initialize an empty list to record information required for precision evaluation

    # for swalign pkg
    match = 1
    mismatch = -1
    scoring = swalign.NucleotideScoringMatrix(match, mismatch)
    sw = swalign.LocalAlignment(scoring)

    if random_sample_method:
        correct_list, correct_dict, misspell_list, misspell_dict = random_sample(correct_list, misspell_list)

    start = time.clock()
    for each_misspell_word in misspell_list:
        majority_vote_list = []
        temp_precision_list = []
        start_1 = time.clock()

        if much_faster is True:
            new_dictionary_list, new_dictionary_dict = cut_down_search_space(each_misspell_word, dictionary_list,
                                                                             keep_first_alphabet=False,
                                                                             left_right_window=2)
        else:
            new_dictionary_list, new_dictionary_dict = dictionary_list, dictionary_dict

        for each_dictionary_word in new_dictionary_list:
            new_dictionary_dict[each_dictionary_word] = editdistance.eval(each_misspell_word, each_dictionary_word)
        find_word_global_distance = min(new_dictionary_dict,
                                        key=new_dictionary_dict.get)  # (global) editdistance, find minimum
        majority_vote_list.append(find_word_global_distance)
        temp_precision_list.extend(choose_max_or_min(new_dictionary_dict, reverse=False))

        for each_dictionary_word in new_dictionary_list:
            new_dictionary_dict[each_dictionary_word] = ngram.NGram.compare(each_misspell_word, each_dictionary_word,
                                                                            N=2)
        find_word_Ngram = max(new_dictionary_dict, key=new_dictionary_dict.get)  # n gram, find maximum
        majority_vote_list.append(find_word_Ngram)
        temp_precision_list.extend(choose_max_or_min(new_dictionary_dict, reverse=True))

        for each_dictionary_word in new_dictionary_list:
            new_dictionary_dict[each_dictionary_word] = sw.align(each_misspell_word, each_dictionary_word).score
        find_word_local_distance = max(new_dictionary_dict,
                                       key=new_dictionary_dict.get)  # (local) editdistance, swaling, find maximum
        majority_vote_list.append(find_word_local_distance)
        temp_precision_list.extend(choose_max_or_min(new_dictionary_dict, reverse=True))

        find_word = most_common(majority_vote_list)
        predicted_word_list.append(find_word)
        precision_list.append(list(set(temp_precision_list)))  # remove duplicated results per precision_list
        end_1 = time.clock()

        print('{} done, find the word: {}, time: {:.2e}'.format(each_misspell_word, find_word, (end_1 - start_1)))
    end = time.clock()

    evaluations.accuracy(correct_word_list=correct_list, misspell_word_list=misspell_list,
                         predicted_word_list=predicted_word_list, method=method)  # evaluate accuracy
    evaluations.precision(correct_word_list=correct_list, misspell_word_list=misspell_list,
                          precision_list=precision_list, method=method)  # evaluate precision

    print('{} method done, time: {}'.format(method, (end - start)))


if __name__ == '__main__':
    majority_vote(much_faster=True)
