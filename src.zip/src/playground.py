# -*- coding:utf-8 -*-
import time
import swalign
import fuzzy
import ngram
import editdistance
import pylev
import jellyfish as j
import os


from Assignment_1.src.algorithms import KT_Algorithms

algos = KT_Algorithms()

test_f = 'actually'
test_t = 'actually'

# ======================================================
# Developed by myself
# ======================================================

print("=" * 64)
print("Algorithms developed pure python")
print("=" * 64)
start = time.clock()
a = algos.Needleman_Wunsch(test_f, test_t)
end = time.clock()
print("Needleman_Wunsch score: {}, time: {:.2e}".format(a, (end - start)))

start = time.clock()
b = algos.Smith_Waterman(test_f, test_t)
end = time.clock()
print("Smith_Waterman score: {}, time: {:.2e}".format(b, (end - start)))

start = time.clock()
n = 1
c = algos.N_gram(test_f, test_t, n=n)
end = time.clock()
print("N-gram score: {}, time: {:.2e}".format(c, (end - start)))

# ======================================================
# Python Packages
# ======================================================
print("=" * 64)
print("packages performance")
print("=" * 64)
start = time.clock()
x = pylev.levenshtein(test_f, test_t)
end = time.clock()
print('pylev pkg score: {}, time: {:.2e}'.format(x, (end - start)))

start = time.clock()
y = editdistance.eval(test_f, test_t)
end = time.clock()
print('editdistance pkg score: {}, time: {:.2e}'.format(y, (end - start)))

start = time.clock()
match = 1
mismatch = -1
scoring = swalign.NucleotideScoringMatrix(match, mismatch)
sw = swalign.LocalAlignment(scoring)
alignment = sw.align(test_f, test_t)
z = alignment.score
end = time.clock()
print('swaling pkg score: {}, time: {:.2e}'.format(z, (end - start)))

start = time.clock()
z2 = ngram.NGram.compare(test_f, test_t, N=1)
end = time.clock()
print('ngram pkg score: {}, time: {:.2e}'.format(z2, (end - start)))

start = time.clock()
soundex = fuzzy.Soundex(4)
test_f_soundex = soundex(test_f)
test_t_soundex = soundex(test_t)
end = time.clock()
print('Fuzzy Soundex pkg score: {}, time: {:.2e}'.format(z2, (end - start)))
print('{} has Soundex: {}'.format(test_f, test_f_soundex))
print('{} has Soundex: {}'.format(test_t, test_t_soundex))

start = time.clock()
z2 = j.levenshtein_distance(test_f, test_t)
end = time.clock()
print('jellyfish pkg score: {}, time: {:.2e}'.format(z2, (end - start)))

start = time.clock()
test_f_soundex = j.soundex(test_f)
test_t_soundex = j.soundex(test_t)
end = time.clock()
print('jellyfish Soundex pkg score: {}, time: {:.2e}'.format(z2, (end - start)))
print('{} has Soundex: {}'.format(test_f, test_f_soundex))
print('{} has Soundex: {}'.format(test_t, test_t_soundex))
