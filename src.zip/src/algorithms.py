# -*- coding:utf-8 -*-
import numpy as np
import string


class KT_Algorithms:
    def __init__(self):
        self.deletion = -1
        self.insertion = -1
        self.replace = -1
        self.match = 1

        if self.match > self.insertion and self.match > self.deletion and self.match > self.replace:
            self.method = 'max'
        elif self.match < self.insertion and self.match < self.deletion and self.match < self.replace:
            self.method = 'min'

    def _equal(self, a, b):
        """
        Check whether two characters match
        """
        if a == b:
            return self.match
        else:
            return self.replace

    def _check_reward_structure(self):
        """
        Check if reward structure is suitable for Smith-Waterman algorithm
        '"""
        assert self.match * self.insertion < 0
        assert self.match * self.deletion < 0
        assert self.match * self.replace < 0

    def Needleman_Wunsch(self, f, t):
        """
        Global Edit Distance
        :param f: Input string
        :param t: Matching string
        :return: (int) Global Edit Distance
        """
        lf = len(f) + 1
        lt = len(t) + 1
        matrix = np.zeros([lt, lf], dtype=np.int32)

        for j in range(lt):
            matrix[j][0] = j * self.insertion

        for k in range(lf):
            matrix[0][k] = k * self.deletion

        if self.method == 'max':
            for j in range(1, lt):
                for k in range(1, lf):
                    matrix[j][k] = max(
                        matrix[j][k - 1] + self.deletion,  # deletion
                        matrix[j - 1][k] + self.insertion,  # insertion
                        matrix[j - 1][k - 1] + self._equal(f[k - 1], t[j - 1])  # replace or match
                    )
        elif self.method == 'min':
            for j in range(1, lt):
                for k in range(1, lf):
                    matrix[j][k] = min(
                        matrix[j][k - 1] + self.deletion,  # deletion
                        matrix[j - 1][k] + self.insertion,  # insertion
                        matrix[j - 1][k - 1] + self._equal(f[k - 1], t[j - 1])  # replace or match
                    )

        return matrix[-1][-1]

    def Smith_Waterman(self, f, t):
        """
        Local Edit Distance
        :param f: Input string
        :param t: Matching string
        :return: Local Edit Distance
        """
        # self._check_reward_structure()  # check if Match has different +/- sign to insert/deletion/replace
        lf = len(f) + 1
        lt = len(t) + 1
        matrix = np.zeros([lt, lf], dtype=np.int32)

        if self.method == 'max':
            for j in range(1, lt):
                for k in range(1, lf):
                    matrix[j][k] = max(
                        0,
                        matrix[j][k - 1] + self.deletion,  # deletion
                        matrix[j - 1][k] + self.insertion,  # insertion
                        matrix[j - 1][k - 1] + self._equal(f[k - 1], t[j - 1])  # replace or match
                    )
        elif self.method == 'min':
            for j in range(1, lt):
                for k in range(1, lf):
                    matrix[j][k] = min(
                        0,
                        matrix[j][k - 1] + self.deletion,  # deletion
                        matrix[j - 1][k] + self.insertion,  # insertion
                        matrix[j - 1][k - 1] + self._equal(f[k - 1], t[j - 1])  # replace or match
                    )

        return np.max(matrix)

    def N_gram(self, f, t, n):
        """
        :param f: Input string
        :param t: Matching string
        :param n: n-gram variable
        :return: n-gram distance
        """
        lf = len(f)
        lt = len(t)

        f_list = []
        t_list = []

        f_list.append('#' + f[0])
        t_list.append('#' + t[0])

        for k in range(lf - n + 1):
            f_list.append(f[k:k + n])

        for j in range(lt - n + 1):
            t_list.append(t[j:j + n])

        f_list.append(f[-1] + '#')

        intersection_list = list(set(f_list) & set(t_list))
        intersection_length = len(intersection_list)

        # ignores any repetition

        return len(f_list) + len(t_list) - 2 * intersection_length

    def neighbourhood_search_k1(self, f):
        """
        Neighbourhood search with k = 1
        :param f: Input string
        :return: a list of strings
        """
        alphabets = string.ascii_lowercase
        neighbour_words_list = []

        # Operation: insertion
        for pivot in range(len(f) + 1):
            for each_alphabet in alphabets:
                l = list(f)  # split a string a list
                l.insert(pivot, each_alphabet)
                processed_l = ''.join(l)
                neighbour_words_list.append(processed_l)

        for pivot in range(len(f)):
            # Operation: deletion
            l = list(f)
            del l[pivot]
            processed_l = ''.join(l)
            neighbour_words_list.append(processed_l)

            # operation: replace
            for each_alphabet in alphabets:
                l = list(f)
                if l[pivot] != each_alphabet:
                    l[pivot] = each_alphabet
                    processed_l = ''.join(l)
                    neighbour_words_list.append(processed_l)

        return neighbour_words_list
